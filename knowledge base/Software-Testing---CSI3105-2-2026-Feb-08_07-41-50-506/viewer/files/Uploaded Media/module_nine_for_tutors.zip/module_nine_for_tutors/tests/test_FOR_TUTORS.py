import pytest
from logic.input_handler_FOR_TUTORS import collect_user_details, collect_user_details_dict, menu_system, menu_system_loop

# Question 1 ans
def test_collect_user_details_bob(monkeypatch):
    inputs = iter(["Bob", "45", "bob@example.com", "Canada"])
    monkeypatch.setattr("builtins.input", lambda _: next(inputs))

    result = collect_user_details()
    expected = "User: Bob, Age: 45, Email: bob@example.com, Country: Canada"
    assert result == expected

# Question 2 ans
def test_collect_user_details_as_dict(monkeypatch):
    inputs = iter(["Alice", "30", "alice@example.com", "Wonderland"])
    monkeypatch.setattr("builtins.input", lambda _: next(inputs))

    result = collect_user_details_dict()
    expected = {
        "name": "Alice",
        "age": "30",
        "email": "alice@example.com",
        "country": "Wonderland"
    }
    assert result == expected

# Question 3 ans
def test_menu_option_joke(monkeypatch, capsys):
    monkeypatch.setattr("builtins.input", lambda _: "4")

    menu_system()
    captured = capsys.readouterr()

    assert "Why did the developer go broke? Because he used up all his cache." in captured.out

# Question 4 ans
def test_menu_loop_until_exit(monkeypatch, capsys):
    inputs = iter(["invalid", "4", "3"])  # simulate 3 rounds of input
    monkeypatch.setattr("builtins.input", lambda _: next(inputs))

    menu_system_loop()
    captured = capsys.readouterr()

    assert "Invalid option selected." in captured.out
    assert "Why did the developer go broke? Because he used up all his cache." in captured.out
    assert "Exiting..." in captured.out


