class B:
    def process(self):
        # Not implemented yet
        pass

    def deny_access(self):
        # Not implemented yet
        pass