class Formatter:
    def format(self, data):  # Simple formatting logic
        return f"Formatted: {data}"