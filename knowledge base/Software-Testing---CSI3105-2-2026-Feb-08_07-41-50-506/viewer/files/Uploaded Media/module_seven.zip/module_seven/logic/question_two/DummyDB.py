class DummyDB:  # Placeholder class to simulate a real DB connection (not implemented)
    def __init__(self, host, port):
        self.host = host
        self.port = port

    def connect(self):
        pass
        # return f"Connected to {self.host}:{self.port}"